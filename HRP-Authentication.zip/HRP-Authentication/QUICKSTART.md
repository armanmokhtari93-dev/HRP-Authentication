# Quick Start Guide

## Setup Overview
HRP-Authentication is now ready for deployment. Follow these steps to get started.

## Step 1: Configure Discord
1. Create a Discord bot in Developer Portal
2. Add bot to your server
3. Create a verification role
4. Get your Guild ID and Role ID
5. Update in `config.lua`

## Step 2: Database Setup
```sql
-- Import the schema
SOURCE sql/hrp_authentication.sql
```

Update database credentials in `config.lua`:
```lua
Config.Database = {
    Host = 'localhost',
    User = 'root',
    Password = 'your_password',
    Database = 'hrp_authentication'
}
```

## Step 3: FiveM Setup
1. Place resource in `resources/` folder
2. Add to `server.cfg`:
   ```
   ensure hrp-authentication
   ```
3. Ensure `oxmysql`, `ox_lib`, and `qb-core` are loaded first

## Step 4: Backend Setup
```bash
cd backend
npm install
npm start
```

The backend will run on `http://localhost:3000`

## Step 5: Test
1. Start server
2. Connect to the server
3. You should see QR code authentication screen
4. Scan with Discord app
5. Verify identity

## Webhooks
Configure Discord webhooks for logging:
- **Connections Webhook**: Player join logs
- **Security Webhook**: Auth failures, suspicious activity
- **Staff Webhook**: Admin actions

## Commands for Admins
- `/hrp_whitelist [discord_id]` - Add to whitelist
- `/hrp_blacklist [discord_id] [reason]` - Add to blacklist
- `/hrp_lookup [discord_id]` - View player info
- `/hrp_session [token]` - Check session status

## HRP-ID Format
Each verified player receives:
- **Format**: `HRP-XXXXXX`
- **Example**: `HRP-204918`
- **Permanence**: Linked to Discord ID forever

## Security Best Practices
1. Always use HTTPS in production
2. Keep Discord token secure (use .env)
3. Enable rate limiting on backend
4. Regularly backup database
5. Monitor logs for suspicious activity
6. Keep dependencies updated

## Troubleshooting

### Player can't connect
- Check Discord is running
- Verify player is in required Discord server
- Check whitelist status: `/hrp_lookup [id]`

### QR code not showing
- Check `Config.WebURL` in config.lua
- Verify backend is running
- Check browser console for errors

### Database connection failed
- Verify MySQL is running
- Check database credentials
- Confirm database schema is imported

### txAdmin integration not working
- Ensure txAdmin is properly installed
- Check txAdmin event names
- Verify resource is in txAdmin whitelist

## Support & Documentation
- See `README.md` for overview
- See `DEPLOYMENT.md` for production setup
- Check FiveM docs: https://docs.fivem.net/
- Check QBCore docs: https://qbcore-framework.com/

---
**Created by**: General Mokhtari  
**Version**: 1.0.0
