-- SQL Schema for HRP-Authentication

-- Users table
CREATE TABLE IF NOT EXISTS hrp_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hrp_id VARCHAR(50) UNIQUE NOT NULL,
    discord_id VARCHAR(100) UNIQUE NOT NULL,
    license VARCHAR(255),
    steam VARCHAR(255),
    xbox VARCHAR(255),
    liveid VARCHAR(255),
    ip_hash VARCHAR(255),
    verified INT DEFAULT 0,
    blacklisted INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_discord_id (discord_id),
    INDEX idx_hrp_id (hrp_id),
    INDEX idx_verified (verified),
    INDEX idx_blacklisted (blacklisted)
);

-- Sessions table
CREATE TABLE IF NOT EXISTS hrp_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    discord_id VARCHAR(100) NOT NULL,
    player_id INT,
    verified INT DEFAULT 0,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_token (session_token),
    INDEX idx_discord_id (discord_id),
    INDEX idx_expires_at (expires_at)
);

-- Whitelist table
CREATE TABLE IF NOT EXISTS hrp_whitelist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    discord_id VARCHAR(100) UNIQUE NOT NULL,
    hrp_id VARCHAR(50),
    whitelisted_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_discord_id (discord_id)
);

-- Blacklist table
CREATE TABLE IF NOT EXISTS hrp_blacklist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    discord_id VARCHAR(100) NOT NULL,
    hrp_id VARCHAR(50),
    reason VARCHAR(255),
    blacklisted_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_discord_id (discord_id),
    INDEX idx_hrp_id (hrp_id)
);

-- Device fingerprint table
CREATE TABLE IF NOT EXISTS hrp_device_fingerprint (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hrp_id VARCHAR(50) NOT NULL,
    fingerprint VARCHAR(255),
    ip_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hrp_id (hrp_id),
    INDEX idx_ip_hash (ip_hash)
);

-- Create database event to clean up expired sessions (optional)
CREATE EVENT IF NOT EXISTS hrp_cleanup_sessions
ON SCHEDULE EVERY 1 HOUR
DO
DELETE FROM hrp_sessions WHERE expires_at < NOW();
