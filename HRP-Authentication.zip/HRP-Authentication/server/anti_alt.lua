-- HRP-Authentication Anti-Alt System

local AntiAlt = {}

-- Check for alt accounts
function AntiAlt.CheckForAlts(ipHash)
    local Database = require('server.database')
    local relatedAccounts = Database.GetRelatedAccounts(ipHash)
    
    if relatedAccounts and #relatedAccounts > Config.MaxAccountsPerIP then
        return true, relatedAccounts
    end
    
    return false, relatedAccounts or {}
end

-- Store device fingerprint
function AntiAlt.StoreFingerprint(hrpId, fingerprint, ipHash)
    MySQL.query('INSERT INTO hrp_device_fingerprint (hrp_id, fingerprint, ip_hash) VALUES (?, ?, ?)',
        { hrpId, fingerprint, ipHash })
end

-- Get account history
function AntiAlt.GetAccountHistory(ipHash)
    local Database = require('server.database')
    return Database.GetRelatedAccounts(ipHash)
end

-- Detect suspicious activity
function AntiAlt.DetectSuspicious(discord, ipHash)
    local relatedAccounts = AntiAlt.GetAccountHistory(ipHash)
    
    if not relatedAccounts or #relatedAccounts == 0 then
        return false
    end

    -- Check if any related accounts are blacklisted
    for _, account in ipairs(relatedAccounts) do
        if account.blacklisted == 1 then
            return true
        end
    end

    return false
end

-- Get linked accounts
function AntiAlt.GetLinkedAccounts(discord)
    local result = MySQL.query.await([[
        SELECT DISTINCT hu.* FROM hrp_users hu
        INNER JOIN hrp_users hu2 ON hu.ip_hash = hu2.ip_hash
        WHERE hu2.discord_id = ?
    ]], { discord })
    
    return result or {}
end

return AntiAlt
