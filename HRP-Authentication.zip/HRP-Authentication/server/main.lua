-- HRP-Authentication Main Server Module

local Database = require('server.database')
local Auth = require('server.auth')
local Sessions = require('server.sessions')
local Whitelist = require('server.whitelist')
local Blacklist = require('server.blacklist')
local AntiAlt = require('server.anti_alt')

-- Initialize on server start
AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if Config.Debug then
            print('^2[HRP-Auth] ^7Starting HRP-Authentication^0')
        end
        
        Database.Init()
    end
end)

-- Player connecting handler
AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    deferrals.defer()
    Wait(1000)
    deferrals.update('HRP Authentication Initializing...')

    local identifiers = Auth.GetPlayerIdentifiers(src)

    if not identifiers.discord then
        deferrals.done('Discord må være åpen for å koble til.')
        return
    end

    -- Check blacklist
    if Blacklist.IsBlacklisted(identifiers.discord) then
        deferrals.done('Du er blakklisted fra denne serveren.')
        return
    end

    -- Check whitelist
    if not Whitelist.IsWhitelisted(identifiers.discord) then
        deferrals.done('Du er ikke på whitelisten.')
        return
    end

    -- Check anti-alt
    local ipHash = Auth.HashIP(identifiers.ip)
    local isAlt, altAccounts = AntiAlt.CheckForAlts(ipHash)
    
    if isAlt then
        deferrals.done('Multiple accounts detected from this IP.')
        if Config.Debug then
            print('^1[HRP-Auth] Alt detection: Player ' .. identifiers.discord .. ' has ' .. #altAccounts .. ' accounts^0')
        end
        return
    end

    -- Create session
    local sessionToken = Sessions.Create(src, identifiers.discord, identifiers.license, identifiers)
    
    TriggerClientEvent('hrp-auth:openAuthUI', src, sessionToken)
    
    deferrals.done()
end)

-- Session verification
RegisterNetEvent('hrp-auth:verifySession', function(token)
    local src = source
    local verified = Sessions.Verify(token)
    
    if verified then
        TriggerEvent('hrp-auth:playerAuthenticated', src)
        TriggerClientEvent('hrp-auth:authSuccess', src)
    else
        DropPlayer(src, 'Authentication failed')
    end
end)

-- Player authenticated event
AddEventHandler('hrp-auth:playerAuthenticated', function(src)
    if Config.Debug then
        print('^2[HRP-Auth] ^7Player authenticated: ' .. src .. '^0')
    end
    
    -- Trigger QBCore or other systems
    TriggerEvent('QBCore:Server:OnPlayerLoad', src)
end)

-- Admin commands
RegisterCommand('hrp_whitelist', function(source, args, rawCommand)
    local src = source
    
    if not IsPlayerAceAllowed(src, 'command.hrp_whitelist') then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'You do not have permission.'}
        })
        return
    end

    if #args < 1 then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'Usage: /hrp_whitelist [discord_id]'}
        })
        return
    end

    Whitelist.Add(args[1], src)
    TriggerClientEvent('chat:addMessage', src, {
        args = {'HRP-Auth', 'Player whitelisted.'}
    })
end, false)

RegisterCommand('hrp_blacklist', function(source, args, rawCommand)
    local src = source
    
    if not IsPlayerAceAllowed(src, 'command.hrp_blacklist') then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'You do not have permission.'}
        })
        return
    end

    if #args < 1 then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'Usage: /hrp_blacklist [discord_id] [reason]'}
        })
        return
    end

    local reason = args[2] or 'No reason provided'
    Blacklist.Add(args[1], reason, src)
    TriggerClientEvent('chat:addMessage', src, {
        args = {'HRP-Auth', 'Player blacklisted.'}
    })
end, false)

RegisterCommand('hrp_lookup', function(source, args, rawCommand)
    local src = source
    
    if not IsPlayerAceAllowed(src, 'command.hrp_lookup') then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'You do not have permission.'}
        })
        return
    end

    if #args < 1 then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'Usage: /hrp_lookup [discord_id or hrp_id]'}
        })
        return
    end

    local user = Database.GetUserByDiscord(args[1]) or Database.GetUserByHRPID(args[1])
    
    if user and #user > 0 then
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'HRP-ID: ' .. user[1].hrp_id .. ' | Discord: ' .. user[1].discord_id .. ' | Verified: ' .. user[1].verified}
        })
    else
        TriggerClientEvent('chat:addMessage', src, {
            args = {'HRP-Auth', 'Player not found.'}
        })
    end
end, false)

if Config.Debug then
    print('^2[HRP-Auth] ^7Main module loaded^0')
end
