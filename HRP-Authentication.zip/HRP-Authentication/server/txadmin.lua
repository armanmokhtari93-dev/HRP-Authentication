-- HRP-Authentication txAdmin Integration

local TxAdmin = {}

-- txAdmin event: Ban sync
RegisterNetEvent('txAdmin:events:playerBanned', function(player, reason)
    local Blacklist = require('server.blacklist')
    local identifiers = GetPlayerIdentifiers(player)
    
    for _, id in pairs(identifiers) do
        if string.find(id, 'discord:') then
            local discord = id:gsub('discord:', '')
            Blacklist.Add(discord, reason or 'Banned by txAdmin', 0)
        end
    end
end)

-- txAdmin event: Player join validation
RegisterNetEvent('txAdmin:events:playerJoining', function(player)
    if Config.Debug then
        print('^2[HRP-Auth] ^7txAdmin validation for player: ' .. player .. '^0')
    end
end)

-- txAdmin event: Server restart handling
RegisterNetEvent('txAdmin:events:serverStop', function()
    if Config.Debug then
        print('^2[HRP-Auth] ^7Server stopping - cleaning up sessions^0')
    end
    
    local Sessions = require('server.sessions')
    Sessions.CleanupExpired()
end)

-- Log event to txAdmin
function TxAdmin.LogEvent(eventType, data)
    if GetResourceMetadata(GetCurrentResourceName(), 'txAdmin-plugin') then
        TriggerEvent('txAdmin:api:registerAlias', {
            type = eventType,
            data = data
        })
    end
end

return TxAdmin
