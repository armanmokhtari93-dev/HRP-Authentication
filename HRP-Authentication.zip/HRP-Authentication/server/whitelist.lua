-- HRP-Authentication Whitelist System

local Whitelist = {}

-- Check if player is whitelisted
function Whitelist.IsWhitelisted(discord)
    if not Config.EnableWhitelist then
        return true
    end

    local Database = require('server.database')
    return Database.IsWhitelisted(discord)
end

-- Whitelist a player
function Whitelist.Add(discord, addedBy)
    local Database = require('server.database')
    
    MySQL.query('INSERT INTO hrp_whitelist (discord_id, whitelisted_by) VALUES (?, ?)', 
        { discord, addedBy })

    if Config.Debug then
        print('^2[HRP-Auth] ^7Player whitelisted: ' .. discord .. '^0')
    end
end

-- Remove from whitelist
function Whitelist.Remove(discord)
    MySQL.query('DELETE FROM hrp_whitelist WHERE discord_id = ?', { discord })
    
    if Config.Debug then
        print('^2[HRP-Auth] ^7Player removed from whitelist: ' .. discord .. '^0')
    end
end

-- Get whitelist count
function Whitelist.GetCount()
    local result = MySQL.query.await('SELECT COUNT(*) as count FROM hrp_whitelist', {})
    return result[1] and result[1].count or 0
end

-- Get all whitelisted players
function Whitelist.GetAll()
    return MySQL.query.await('SELECT * FROM hrp_whitelist', {})
end

return Whitelist
