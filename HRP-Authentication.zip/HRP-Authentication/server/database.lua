-- HRP-Authentication Database Module
-- Handles all database operations

local Database = {}

-- Initialize database tables
function Database.Init()
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS hrp_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hrp_id VARCHAR(50) UNIQUE,
            discord_id VARCHAR(100) UNIQUE,
            license VARCHAR(255),
            steam VARCHAR(255),
            xbox VARCHAR(255),
            liveid VARCHAR(255),
            ip_hash VARCHAR(255),
            verified INT DEFAULT 0,
            blacklisted INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (discord_id),
            INDEX (hrp_id)
        )
    ]])

    MySQL.query([[
        CREATE TABLE IF NOT EXISTS hrp_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_token VARCHAR(255) UNIQUE,
            discord_id VARCHAR(100),
            player_id INT,
            verified INT DEFAULT 0,
            expires_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (session_token),
            INDEX (discord_id)
        )
    ]])

    MySQL.query([[
        CREATE TABLE IF NOT EXISTS hrp_whitelist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            discord_id VARCHAR(100) UNIQUE,
            hrp_id VARCHAR(50),
            whitelisted_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (discord_id)
        )
    ]])

    MySQL.query([[
        CREATE TABLE IF NOT EXISTS hrp_blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            discord_id VARCHAR(100),
            hrp_id VARCHAR(50),
            reason VARCHAR(255),
            blacklisted_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (discord_id),
            INDEX (hrp_id)
        )
    ]])

    MySQL.query([[
        CREATE TABLE IF NOT EXISTS hrp_device_fingerprint (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hrp_id VARCHAR(50),
            fingerprint VARCHAR(255),
            ip_hash VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (hrp_id)
        )
    ]])

    if Config.Debug then
        print('^2[HRP-Auth] ^7Database tables initialized!^0')
    end
end

-- Get or create user
function Database.GetOrCreateUser(discord, license, steam, xbox, liveid, ipHash)
    return MySQL.query.await('SELECT * FROM hrp_users WHERE discord_id = ?', { discord })
end

-- Create new HRP ID
function Database.CreateHRPID()
    local hrpId = 'HRP-' .. tostring(math.random(100000, 999999))
    return hrpId
end

-- Get user by Discord ID
function Database.GetUserByDiscord(discord)
    return MySQL.query.await('SELECT * FROM hrp_users WHERE discord_id = ?', { discord })
end

-- Get user by HRP ID
function Database.GetUserByHRPID(hrpId)
    return MySQL.query.await('SELECT * FROM hrp_users WHERE hrp_id = ?', { hrpId })
end

-- Check if user is whitelisted
function Database.IsWhitelisted(discord)
    local result = MySQL.query.await('SELECT * FROM hrp_whitelist WHERE discord_id = ?', { discord })
    return result and #result > 0
end

-- Check if user is blacklisted
function Database.IsBlacklisted(discord)
    local result = MySQL.query.await('SELECT * FROM hrp_blacklist WHERE discord_id = ?', { discord })
    return result and #result > 0
end

-- Get related accounts (anti-alt detection)
function Database.GetRelatedAccounts(ipHash)
    return MySQL.query.await('SELECT * FROM hrp_users WHERE ip_hash = ?', { ipHash })
end

-- Update session verification
function Database.UpdateSessionVerification(token, verified)
    MySQL.query('UPDATE hrp_sessions SET verified = ? WHERE session_token = ?', { verified, token })
end

-- Get session by token
function Database.GetSessionByToken(token)
    return MySQL.query.await('SELECT * FROM hrp_sessions WHERE session_token = ? AND expires_at > NOW()', { token })
end

-- Create session
function Database.CreateSession(token, discordId, playerId, expiresAt)
    MySQL.query('INSERT INTO hrp_sessions (session_token, discord_id, player_id, expires_at) VALUES (?, ?, ?, ?)', 
        { token, discordId, playerId, expiresAt })
end

return Database
