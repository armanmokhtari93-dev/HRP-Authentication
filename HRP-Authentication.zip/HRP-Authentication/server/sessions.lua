-- HRP-Authentication Session Management

local Sessions = {}

-- Active sessions in memory
local activeSessions = {}

-- Create new session
function Sessions.Create(src, discord, license, identifiers)
    local Auth = require('server.auth')
    local Database = require('server.database')

    local token = Auth.GenerateSecureToken()
    local expiresAt = os.date('%Y-%m-%d %H:%M:%S', os.time() + Config.SessionTimeout)

    activeSessions[token] = {
        player = src,
        discord = discord,
        license = license,
        identifiers = identifiers,
        verified = false,
        created = os.time(),
        expires = os.time() + Config.SessionTimeout
    }

    -- Store in database
    Database.CreateSession(token, discord, src, expiresAt)

    if Config.Debug then
        print('^2[HRP-Auth] ^7Session created: ' .. token .. '^0')
    end

    return token
end

-- Get session
function Sessions.Get(token)
    return activeSessions[token]
end

-- Verify session
function Sessions.Verify(token)
    local session = activeSessions[token]
    
    if not session then
        return false
    end

    if os.time() > session.expires then
        Sessions.Destroy(token)
        return false
    end

    session.verified = true
    return true
end

-- Destroy session
function Sessions.Destroy(token)
    activeSessions[token] = nil
    if Config.Debug then
        print('^2[HRP-Auth] ^7Session destroyed: ' .. token .. '^0')
    end
end

-- Cleanup expired sessions
function Sessions.CleanupExpired()
    for token, session in pairs(activeSessions) do
        if os.time() > session.expires then
            Sessions.Destroy(token)
        end
    end
end

-- Get all sessions for a player
function Sessions.GetPlayerSessions(src)
    local playerSessions = {}
    for token, session in pairs(activeSessions) do
        if session.player == src then
            table.insert(playerSessions, token)
        end
    end
    return playerSessions
end

return Sessions
