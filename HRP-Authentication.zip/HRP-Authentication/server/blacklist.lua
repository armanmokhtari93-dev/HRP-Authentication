-- HRP-Authentication Blacklist System

local Blacklist = {}

-- Check if player is blacklisted
function Blacklist.IsBlacklisted(discord)
    local Database = require('server.database')
    return Database.IsBlacklisted(discord)
end

-- Blacklist a player
function Blacklist.Add(discord, reason, addedBy)
    local Database = require('server.database')
    
    MySQL.query('INSERT INTO hrp_blacklist (discord_id, reason, blacklisted_by) VALUES (?, ?, ?)', 
        { discord, reason, addedBy })

    if Config.Debug then
        print('^2[HRP-Auth] ^7Player blacklisted: ' .. discord .. ' - Reason: ' .. reason .. '^0')
    end

    -- Kick the player if online
    for _, player in ipairs(GetPlayers()) do
        local identifiers = GetPlayerIdentifiers(player)
        for _, id in pairs(identifiers) do
            if string.find(id, 'discord:') and id:gsub('discord:', '') == discord then
                DropPlayer(player, 'You have been blacklisted from this server. Reason: ' .. reason)
            end
        end
    end
end

-- Remove from blacklist
function Blacklist.Remove(discord)
    MySQL.query('DELETE FROM hrp_blacklist WHERE discord_id = ?', { discord })
    
    if Config.Debug then
        print('^2[HRP-Auth] ^7Player removed from blacklist: ' .. discord .. '^0')
    end
end

-- Get blacklist count
function Blacklist.GetCount()
    local result = MySQL.query.await('SELECT COUNT(*) as count FROM hrp_blacklist', {})
    return result[1] and result[1].count or 0
end

-- Get all blacklisted players
function Blacklist.GetAll()
    return MySQL.query.await('SELECT * FROM hrp_blacklist', {})
end

return Blacklist
