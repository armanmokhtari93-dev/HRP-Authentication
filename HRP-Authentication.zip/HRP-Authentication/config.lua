Config = {}

-- Debug mode
Config.Debug = true

-- Discord Configuration
Config.DiscordGuild = '1476233316574433353'
Config.RequiredRole = '1476234812149731361'

-- Webhooks
Config.Webhooks = {
    Connections = 'https://discord.com/api/webhooks/YOUR_CONNECTION_WEBHOOK',
    Security = 'https://discord.com/api/webhooks/YOUR_SECURITY_WEBHOOK',
    Staff = 'https://discord.com/api/webhooks/YOUR_STAFF_WEBHOOK'
}

-- Session settings
Config.SessionTimeout = 300 -- 5 minutes
Config.MaxAccountsPerIP = 2

-- Feature flags
Config.EnableWhitelist = true
Config.EnableAntiAlt = true

-- Backend URL
Config.WebURL = 'http://localhost:3000'

-- Admin groups
Config.AdminGroups = {
    'god',
    'admin'
}

-- Database
Config.Database = {
    Host = 'localhost',
    User = 'root',
    Password = 'password',
    Database = 'hrp_authentication'
}
