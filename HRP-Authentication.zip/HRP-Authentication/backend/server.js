const express = require('express');
const app = express();

app.use(express.json());

// Middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

// Routes
const verifyRoutes = require('./routes/verify');
const discordRoutes = require('./routes/discord');
const sessionRoutes = require('./routes/sessions');

app.use('/verify', verifyRoutes);
app.use('/discord', discordRoutes);
app.use('/sessions', sessionRoutes);

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('[HRP-Auth Backend Error]', err);
    res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`[HRP-Auth Backend] Server running on port ${PORT}`);
});
