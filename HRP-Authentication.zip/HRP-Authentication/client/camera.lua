-- HRP-Authentication Camera Control

local authCameraActive = false
local authCam = nil

-- Set up authentication camera
function SetupAuthCamera()
    authCameraActive = true
    
    -- Get player position
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    -- Create camera looking at player
    authCam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamCoord(authCam, playerCoords.x + 5.0, playerCoords.y + 5.0, playerCoords.z + 1.0)
    SetCamRot(authCam, 0.0, 0.0, GetEntityHeading(playerPed) + 180.0, 2)
    PointCamAtEntity(authCam, playerPed, 0.0, 0.0, 0.0, true)
    RenderScriptCams(true, false, 0, true, false)
    
    if Config.Debug then
        print('^2[HRP-Auth Camera] ^7Auth camera set up^0')
    end
end

-- Disable authentication camera
function DisableAuthCamera()
    if authCam then
        RenderScriptCams(false, false, 0, true, false)
        DestroyCam(authCam, false)
        authCam = nil
    end
    authCameraActive = false
    
    if Config.Debug then
        print('^2[HRP-Auth Camera] ^7Auth camera disabled^0')
    end
end

-- Listen for auth UI open
RegisterNetEvent('hrp-auth:setupCamera', function()
    SetupAuthCamera()
end)

-- Listen for auth close
RegisterNetEvent('hrp-auth:closeCamera', function()
    DisableAuthCamera()
end)

-- Cleanup on resource stop
AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if authCameraActive then
            DisableAuthCamera()
        end
    end
end)
