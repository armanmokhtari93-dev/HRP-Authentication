-- HRP-Authentication NUI Handler

local function loadNUI()
    -- Send initial data to NUI
    SendNUIMessage({
        action = 'initialize',
        serverName = GetConvar('sv_projectname', 'FiveM Server')
    })
end

-- Initialize on resource start
AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        loadNUI()
        if Config.Debug then
            print('^2[HRP-Auth NUI] ^7NUI handler initialized^0')
        end
    end
end)

-- Listen for NUI messages
RegisterNUICallback('log', function(data, cb)
    if Config.Debug then
        print('^2[HRP-Auth NUI] ^7' .. data.message .. '^0')
    end
    cb('ok')
end)

RegisterNUICallback('error', function(data, cb)
    print('^1[HRP-Auth NUI Error] ^7' .. (data.message or 'Unknown error') .. '^0')
    cb('ok')
end)
