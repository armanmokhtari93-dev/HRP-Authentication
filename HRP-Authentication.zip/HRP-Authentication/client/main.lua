-- HRP-Authentication Client Main Module

local isAuthenticating = false
local currentToken = nil

-- Open authentication UI
RegisterNetEvent('hrp-auth:openAuthUI', function(token)
    currentToken = token
    isAuthenticating = true
    
    SendNUIMessage({
        action = 'openAuth',
        token = token,
        qrUrl = Config.WebURL .. '/qr/' .. token
    })
    
    SetNuiFocus(true, true)
    
    if Config.Debug then
        print('^2[HRP-Auth Client] ^7Auth UI opened with token: ' .. token .. '^0')
    end
end)

-- Close authentication UI
RegisterNUICallback('closeAuth', function(data, cb)
    SetNuiFocus(false, false)
    isAuthenticating = false
    cb('ok')
end)

-- Verify session
RegisterNUICallback('verifySession', function(data, cb)
    if data.token then
        TriggerServerEvent('hrp-auth:verifySession', data.token)
        cb('ok')
    else
        cb('error')
    end
end)

-- Authentication success
RegisterNetEvent('hrp-auth:authSuccess', function()
    isAuthenticating = false
    SendNUIMessage({
        action = 'closeAuth'
    })
    SetNuiFocus(false, false)
    
    if Config.Debug then
        print('^2[HRP-Auth Client] ^7Authentication successful^0')
    end
end)

-- Disable input during auth
Citizen.CreateThread(function()
    while true do
        Wait(0)
        
        if isAuthenticating then
            DisableAllControlActions(0)
        end
    end
end)

if Config.Debug then
    print('^2[HRP-Auth Client] ^7Client module loaded^0')
end
