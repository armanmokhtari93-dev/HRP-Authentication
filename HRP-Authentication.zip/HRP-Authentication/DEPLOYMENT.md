# Deployment Guide for HRP-Authentication

## Linux VPS Setup (Ubuntu 24.04)

### 1. Prerequisites
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install NGINX
sudo apt install -y nginx

# Install PM2
sudo npm install -g pm2
```

### 2. Backend Deployment
```bash
# Clone/copy repository
cd /opt/hrp-authentication/backend

# Install dependencies
npm install

# Start with PM2
pm2 start server.js --name "hrp-auth-backend"
pm2 save
pm2 startup
```

### 3. NGINX Configuration
Create `/etc/nginx/sites-available/hrp-auth`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/hrp-auth /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 4. SSL Certificate (Let's Encrypt)
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot certify -d your-domain.com
```

### 5. Database Setup
```bash
# Install MySQL
sudo apt install -y mysql-server

# Import schema
mysql -u root -p < sql/hrp_authentication.sql
```

### 6. Environment Variables
Create `.env`:
```
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_DATABASE=hrp_authentication
DISCORD_TOKEN=your_token
DISCORD_GUILD_ID=your_guild_id
```

## Production Checklist
- [ ] SSL certificate installed
- [ ] Database backups configured
- [ ] PM2 auto-restart enabled
- [ ] Firewall rules configured
- [ ] Rate limiting enabled
- [ ] Webhook endpoints secured
- [ ] Environment variables set
- [ ] Regular updates scheduled

## Monitoring
```bash
# View PM2 logs
pm2 logs

# Monitor system
pm2 monit

# Setup auto-restart on reboot
pm2 startup
pm2 save
```

## Troubleshooting
- Check logs: `pm2 logs hrp-auth-backend`
- Verify NGINX: `sudo nginx -t`
- Test backend: `curl http://localhost:3000/health`
