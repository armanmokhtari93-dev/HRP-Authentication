<!-- API Documentation for HRP-Authentication Backend -->

# API Reference

## Base URL
```
http://localhost:3000
```

## Authentication Endpoints

### POST /verify/:token
Verify a session token

**Parameters:**
- `token` (string, path) - Session token to verify

**Response:**
```json
{
    "success": true,
    "message": "Token verified successfully",
    "token": "abc123...",
    "verified_at": "2024-05-28T12:00:00Z"
}
```

### POST /verify/discord/:discordId
Verify Discord membership

**Parameters:**
- `discordId` (string, path) - Discord user ID

**Response:**
```json
{
    "success": true,
    "message": "Discord membership verified",
    "discord_id": "123456789"
}
```

## Discord OAuth Endpoints

### GET /discord/callback
OAuth callback endpoint

**Query Parameters:**
- `code` (string) - Authorization code from Discord
- `state` (string) - State parameter for security

**Response:**
```json
{
    "success": true,
    "message": "Discord authentication successful"
}
```

### GET /discord/user/:discordId
Get Discord user information

**Parameters:**
- `discordId` (string, path) - Discord user ID

**Response:**
```json
{
    "success": true,
    "discord_id": "123456789",
    "username": "User#0000"
}
```

## Session Management Endpoints

### POST /sessions/create
Create a new authentication session

**Body:**
```json
{
    "discord_id": "123456789",
    "player_id": 1
}
```

**Response:**
```json
{
    "success": true,
    "token": "abc123...",
    "expires_in": 300,
    "created_at": "2024-05-28T12:00:00Z"
}
```

### GET /sessions/:token
Get session information

**Parameters:**
- `token` (string, path) - Session token

**Response:**
```json
{
    "success": true,
    "token": "abc123...",
    "verified": false
}
```

### POST /sessions/:token/verify
Verify a session

**Parameters:**
- `token` (string, path) - Session token

**Response:**
```json
{
    "success": true,
    "message": "Session verified",
    "token": "abc123..."
}
```

### DELETE /sessions/:token
Destroy a session

**Parameters:**
- `token` (string, path) - Session token

**Response:**
```json
{
    "success": true,
    "message": "Session deleted"
}
```

## Health Check

### GET /health
Check backend status

**Response:**
```json
{
    "status": "ok",
    "timestamp": "2024-05-28T12:00:00Z"
}
```

## Error Responses

### 400 Bad Request
```json
{
    "success": false,
    "error": "Invalid token"
}
```

### 404 Not Found
```json
{
    "success": false,
    "error": "Session not found"
}
```

### 500 Internal Server Error
```json
{
    "success": false,
    "error": "Internal server error"
}
```

## Rate Limiting
- Recommended: 100 requests per minute per IP
- Implement using express-rate-limit

## CORS
- All origins allowed (configure in production)
- Headers: Content-Type, Authorization

## Authentication Headers
```
Authorization: Bearer <token>
Content-Type: application/json
```

## Webhook Payloads

### Connection Webhook
```json
{
    "embeds": [{
        "title": "Player Connected",
        "description": "Discord ID: 123456789",
        "timestamp": "2024-05-28T12:00:00Z"
    }]
}
```

### Security Webhook
```json
{
    "embeds": [{
        "title": "Security Alert",
        "description": "Alt account detected",
        "color": 16711680
    }]
}
```

---
API Version: 1.0.0  
Last Updated: 2024-05-28
