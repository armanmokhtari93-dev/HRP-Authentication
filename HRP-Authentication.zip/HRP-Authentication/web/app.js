// HRP-Authentication NUI Frontend

let currentToken = null;
let verificationInterval = null;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('[HRP-Auth] Frontend initialized');
    
    const closeBtn = document.getElementById('close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeAuth);
    }
});

// Listen for messages from server
window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'openAuth') {
        openAuth(data.token, data.qrUrl);
    } else if (data.action === 'closeAuth') {
        closeAuth();
    } else if (data.action === 'initialize') {
        console.log('[HRP-Auth] Initialized for: ' + data.serverName);
    } else if (data.action === 'verificationSuccess') {
        verificationSuccess();
    } else if (data.action === 'verificationFailed') {
        verificationFailed(data.reason);
    }
});

// Open authentication UI
function openAuth(token, qrUrl) {
    console.log('[HRP-Auth] Opening auth UI with token: ' + token);
    
    currentToken = token;
    const container = document.getElementById('auth-container');
    const qrImage = document.getElementById('qr-code');
    const statusText = document.getElementById('status-text');
    
    if (container && qrImage) {
        qrImage.src = qrUrl;
        container.classList.remove('hidden');
        statusText.textContent = 'Waiting for verification...';
        
        // Start polling for verification
        startVerificationPolling();
    }
}

// Close authentication UI
function closeAuth() {
    console.log('[HRP-Auth] Closing auth UI');
    
    const container = document.getElementById('auth-container');
    if (container) {
        container.classList.add('hidden');
    }
    
    if (verificationInterval) {
        clearInterval(verificationInterval);
        verificationInterval = null;
    }
    
    // Send close message to server
    fetch(`http://${GetParentResourceName()}/closeAuth`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            token: currentToken
        })
    });
}

// Start verification polling
function startVerificationPolling() {
    const statusText = document.getElementById('status-text');
    
    verificationInterval = setInterval(function() {
        if (!currentToken) return;
        
        // In a real implementation, this would check the backend for verification status
        console.log('[HRP-Auth] Polling verification status...');
        
        fetch(`http://${GetParentResourceName()}/verifySession`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                token: currentToken
            })
        }).then(response => {
            if (response.ok) {
                statusText.textContent = 'Verified! Connecting...';
                verificationSuccess();
            }
        }).catch(err => {
            console.error('[HRP-Auth] Verification check failed:', err);
        });
    }, 3000); // Check every 3 seconds
}

// Verification success
function verificationSuccess() {
    console.log('[HRP-Auth] Verification successful');
    
    const statusText = document.getElementById('status-text');
    if (statusText) {
        statusText.textContent = '✓ Verified! Connecting...';
    }
    
    setTimeout(function() {
        closeAuth();
    }, 2000);
}

// Verification failed
function verificationFailed(reason) {
    console.error('[HRP-Auth] Verification failed: ' + reason);
    
    const statusText = document.getElementById('status-text');
    if (statusText) {
        statusText.textContent = '✗ Verification failed: ' + (reason || 'Unknown error');
        statusText.style.color = '#ff4444';
    }
}

// Helper function to get parent resource name
function GetParentResourceName() {
    return 'hrp-authentication';
}
