fx_version 'cerulean'
game 'gta5'

lua54 'yes'

name 'HRP-Authentication'
author 'General Mokhtari'
description 'Advanced Authentication System for QBCore'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/database.lua',
    'server/auth.lua',
    'server/sessions.lua',
    'server/whitelist.lua',
    'server/blacklist.lua',
    'server/anti_alt.lua',
    'server/txadmin.lua',
    'server/main.lua'
}

client_scripts {
    'client/main.lua',
    'client/nui.lua',
    'client/camera.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/assets/*'
}
