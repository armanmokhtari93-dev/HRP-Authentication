# Architecture Diagram

## Authentication Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Player Joins FiveM Server                       │
└──────────────────────────────┬──────────────────────────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │ playerConnecting     │
                    │ Event Triggered      │
                    └──────────┬───────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Extract Discord & License IDs        │
            │ Get IP Hash                          │
            └──────────────────┬───────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │ Check Blacklist      │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ Check Whitelist      │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ Check for Alts       │
                    │ (IP Hash Lookup)     │
                    └──────────┬───────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Create Session                       │
            │ Generate Secure Token (64 chars)     │
            │ Create QR Code                       │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Trigger Client: openAuthUI           │
            │ Display QR Code on NUI               │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Player Scans QR with Discord App     │
            │ Redirects to Backend Verification    │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Backend Verifies:                    │
            │ - Token validity                     │
            │ - Discord OAuth                      │
            │ - Guild membership                   │
            │ - Required role                      │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Create/Update HRP User:              │
            │ - Generate HRP-ID                    │
            │ - Store identifiers                  │
            │ - Store device fingerprint           │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Trigger Server: playerAuthenticated  │
            │ Client receives: authSuccess event   │
            └──────────────────┬───────────────────┘
                               ↓
            ┌──────────────────────────────────────┐
            │ Close Auth UI                        │
            │ Load QBCore Character                │
            │ Player Connected                     │
            └──────────────────────────────────────┘
```

## System Components

```
FiveM Server
├── Server-Side
│   ├── Main Handler (playerConnecting event)
│   ├── Session Manager (token/expiry)
│   ├── Auth Module (identification)
│   ├── Whitelist Module
│   ├── Blacklist Module
│   ├── Anti-Alt Detection
│   └── Database Manager
├── Client-Side
│   ├── NUI Handler
│   ├── Camera System
│   └── Event Listeners
└── Web UI
    ├── Authentication Screen
    ├── QR Code Display
    └── Status Updates

Backend (Node.js/Express)
├── API Routes
│   ├── Verification endpoints
│   ├── Discord OAuth
│   └── Session management
├── Discord Integration
│   ├── OAuth handler
│   ├── Guild verification
│   └── Role verification
└── Database Interface
    ├── User records
    ├── Session storage
    └── Device fingerprints

Database (MySQL)
├── hrp_users (user records)
├── hrp_sessions (active sessions)
├── hrp_whitelist (approved players)
├── hrp_blacklist (banned players)
└── hrp_device_fingerprint (alt detection)
```

## Session Lifecycle

```
Session Created
     ↓
   Token Generated (64-char random)
     ↓
   Session stored in memory + database
     ↓
   Expiry timer started (5 min default)
     ↓
   Player scans QR
     ↓
   Backend verifies Discord
     ↓
   Session marked as verified
     ↓
   Client receives confirmation
     ↓
   Session cleaned up
     ↓
   Player authenticated
```

## Anti-Alt System

```
Player connects
     ↓
IP Hash calculated
     ↓
Query database for accounts with same IP hash
     ↓
Compare against Max Accounts Per IP (default: 2)
     ↓
If exceeded:
  - Log suspicious activity
  - Send security webhook
  - Kick player with message
     ↓
If OK:
  - Store device fingerprint
  - Continue authentication
```

---
Generated for HRP-Authentication v1.0.0
